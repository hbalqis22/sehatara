import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { CalendarCheck, Loader2, Star, Video, Building2 } from 'lucide-react'
import { Reveal } from '@/components/Reveal'
import doctors, { type Doctor } from '@/data/doctors'

export const Route = createFileRoute('/konsultasi')({
  head: () => ({ meta: [{ title: 'Konsultasi Dokter — Sehatara' }] }),
  component: Consult,
})

const filters = ['Semua', 'Umum', 'Gizi', 'Jantung', 'Saraf', 'Psikologi', 'Anak'] as const
const slots = ['08.00', '09.30', '11.00', '13.00', '14.30', '16.00', '19.00']

const encode = (data: Record<string, string>) =>
  Object.entries(data)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')

const initials = (name: string) =>
  name
    .replace(/^dr\.\s*/, '')
    .split(/[\s,]+/)
    .slice(0, 2)
    .map((p) => p[0])
    .join('')

function Consult() {
  const [filter, setFilter] = useState<(typeof filters)[number]>('Semua')
  const [selected, setSelected] = useState<Doctor>(doctors[4])
  const list = doctors.filter((d) => filter === 'Semua' || d.category === filter)

  return (
    <div className="mx-auto max-w-6xl px-6 pt-32 md:pt-40">
      <p className="rise text-xs font-semibold uppercase tracking-[.2em] text-clay">Konsultasi</p>
      <h1 className="rise mt-3 max-w-4xl font-display text-6xl font-light leading-[.95] text-forest [animation-delay:.1s] md:text-8xl">
        Bicara dengan <em className="text-clay">ahlinya.</em>
      </h1>
      <p className="rise mt-6 max-w-xl text-lg text-ink/65 [animation-delay:.2s]">
        Pilih dokter atau psikolog, tentukan jadwal, dan kami akan mengonfirmasi janji temu dalam 1×24 jam.
      </p>

      <div className="rise mt-10 flex flex-wrap gap-2 [animation-delay:.3s]">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-5 py-2 text-sm font-medium transition ${filter === f ? 'bg-forest text-cream' : 'bg-paper text-forest ring-1 ring-forest/10 hover:bg-sage/30'}`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1.2fr_1fr]">
        <div className="grid content-start gap-4 sm:grid-cols-2">
          {list.map((d, i) => (
            <Reveal key={d.id} delay={i * 70}>
              <button
                onClick={() => {
                  setSelected(d)
                  document.getElementById('form-janji')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
                }}
                className={`group relative h-full w-full overflow-hidden rounded-[2rem] p-6 text-left transition duration-500 hover:-translate-y-1 ${
                  selected.id === d.id ? 'bg-forest text-cream shadow-[0_24px_50px_-24px_rgba(29,58,47,.8)]' : 'bg-paper ring-1 ring-forest/10'
                }`}
              >
                <div className="flex items-start justify-between">
                  <span className={`grid h-16 w-16 place-items-center rounded-[1.4rem] font-display text-2xl text-forest transition duration-500 group-hover:rounded-full ${d.tone}`}>
                    {initials(d.name)}
                  </span>
                  {d.online && (
                    <span className="flex items-center gap-1.5 rounded-full bg-sage/40 px-2.5 py-1 text-[11px] font-semibold">
                      <span className="relative flex h-2 w-2">
                        <span className="absolute inset-0 animate-pulse-ring rounded-full bg-moss" />
                        <span className="relative h-2 w-2 rounded-full bg-moss" />
                      </span>
                      Online
                    </span>
                  )}
                </div>
                <h3 className="mt-5 font-display text-xl leading-snug">{d.name}</h3>
                <p className="text-sm opacity-65">{d.specialty}</p>
                <div className="mt-4 flex items-center gap-3 text-sm">
                  <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-butter text-butter" /> {d.rating.toFixed(1)}</span>
                  <span className="opacity-50">({d.reviews})</span>
                  <span className="opacity-50">·</span>
                  <span className="opacity-70">{d.experience} thn</span>
                </div>
                <p className="mt-3 text-xs opacity-60">{d.schedule}</p>
              </button>
            </Reveal>
          ))}
        </div>

        <div id="form-janji" className="scroll-mt-28 lg:sticky lg:top-28 lg:self-start">
          <BookingForm doctor={selected} />
        </div>
      </div>
    </div>
  )
}

function BookingForm({ doctor }: { doctor: Doctor }) {
  const [mode, setMode] = useState<'Video call' | 'Tatap muka'>('Video call')
  const [slot, setSlot] = useState(slots[1])
  const [status, setStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle')
  const today = new Date().toISOString().slice(0, 10)

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setStatus('sending')
    const data = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>
    try {
      const res = await fetch('/__forms.html', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encode({ ...data, 'form-name': 'konsultasi', dokter: doctor.name, mode, jam: slot }),
      })
      setStatus(res.ok ? 'done' : 'error')
    } catch {
      setStatus('error')
    }
  }

  if (status === 'done')
    return (
      <div className="rise rounded-[2.5rem] bg-sage p-10 text-center text-forest">
        <CalendarCheck className="mx-auto h-14 w-14" />
        <h2 className="mt-4 font-display text-3xl">Permintaan terkirim!</h2>
        <p className="mt-3 text-forest/75">
          Janji dengan <strong>{doctor.name}</strong> pukul {slot} sedang kami proses. Konfirmasi akan dikirim lewat email atau WhatsApp.
        </p>
        <button onClick={() => setStatus('idle')} className="mt-6 rounded-full bg-forest px-6 py-3 font-semibold text-cream">
          Buat janji lain
        </button>
      </div>
    )

  const field = 'w-full rounded-2xl bg-cream px-4 py-3 outline-none ring-1 ring-forest/10 transition focus:ring-2 focus:ring-clay'

  return (
    <form onSubmit={onSubmit} className="rounded-[2.5rem] bg-paper p-7 ring-1 ring-forest/10 md:p-9">
      <input type="hidden" name="form-name" value="konsultasi" />
      <p className="hidden"><label>Jangan isi: <input name="bot-field" /></label></p>

      <p className="text-xs font-semibold uppercase tracking-[.2em] text-clay">Buat janji dengan</p>
      <h2 key={doctor.id} className="rise mt-1 font-display text-3xl text-forest">{doctor.name}</h2>
      <p className="text-sm text-ink/60">{doctor.specialty}</p>

      <div className="mt-6 grid grid-cols-2 gap-2">
        {([['Video call', Video], ['Tatap muka', Building2]] as const).map(([m, Icon]) => (
          <button
            type="button"
            key={m}
            onClick={() => setMode(m)}
            className={`flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold transition ${mode === m ? 'bg-forest text-cream' : 'bg-cream text-forest hover:bg-sage/30'}`}
          >
            <Icon className="h-4 w-4" /> {m}
          </button>
        ))}
      </div>

      <label className="mt-5 block text-sm font-medium text-ink/70">
        Tanggal
        <input type="date" name="tanggal" min={today} required className={`${field} mt-1.5`} />
      </label>

      <p className="mt-5 text-sm font-medium text-ink/70">Jam</p>
      <div className="mt-1.5 flex flex-wrap gap-2">
        {slots.map((s) => (
          <button
            type="button"
            key={s}
            onClick={() => setSlot(s)}
            className={`rounded-xl px-3.5 py-2 text-sm font-medium transition ${slot === s ? 'bg-clay text-cream' : 'bg-cream text-forest hover:bg-butter/50'}`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="block text-sm font-medium text-ink/70">
          Nama lengkap
          <input name="nama" required className={`${field} mt-1.5`} />
        </label>
        <label className="block text-sm font-medium text-ink/70">
          No. WhatsApp
          <input name="telepon" type="tel" required placeholder="08…" className={`${field} mt-1.5`} />
        </label>
      </div>
      <label className="mt-4 block text-sm font-medium text-ink/70">
        Email
        <input name="email" type="email" required className={`${field} mt-1.5`} />
      </label>
      <label className="mt-4 block text-sm font-medium text-ink/70">
        Keluhan singkat
        <textarea name="keluhan" rows={3} required placeholder="Ceritakan keluhan atau tujuan konsultasimu" className={`${field} mt-1.5 resize-none`} />
      </label>

      <button
        disabled={status === 'sending'}
        className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-forest py-4 font-semibold text-cream transition hover:-translate-y-0.5 hover:bg-moss disabled:opacity-60"
      >
        {status === 'sending' && <Loader2 className="h-5 w-5 animate-spin" />}
        Kirim Permintaan Janji
      </button>
      {status === 'error' && <p className="mt-3 text-center text-sm text-clay">Maaf, terjadi kendala. Silakan coba lagi.</p>}
      <p className="mt-4 text-center text-xs text-ink/50">Untuk kondisi darurat, segera hubungi 119 atau IGD terdekat.</p>
    </form>
  )
}
