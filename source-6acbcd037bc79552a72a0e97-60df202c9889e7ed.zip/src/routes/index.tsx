import { Link, createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  Droplets,
  Flame,
  HeartPulse,
  Moon,
  Scale,
  Sparkles,
  Star,
  Stethoscope,
  Wind,
} from 'lucide-react'
import { Reveal } from '@/components/Reveal'
import articles from '@/data/articles'
import { img } from '@/lib/img'

export const Route = createFileRoute('/')({ component: Home })

function Home() {
  return (
    <>
      <Hero />
      <Marquee />
      <Features />
      <DailyCheck />
      <Stats />
      <Journal />
      <Testimonials />
      <Cta />
    </>
  )
}

function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 md:pt-40">
      <div className="pointer-events-none absolute -left-32 top-20 h-96 w-96 animate-blob bg-sage/40 blur-2xl" />
      <div className="pointer-events-none absolute right-0 top-0 h-72 w-72 animate-blob bg-butter/40 blur-2xl [animation-delay:-6s]" />

      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-6 lg:grid-cols-[1.1fr_.9fr]">
        <div>
          <p className="rise inline-flex items-center gap-2 rounded-full border border-forest/15 bg-paper/70 px-4 py-1.5 text-xs font-semibold uppercase tracking-[.18em] text-moss">
            <Sparkles className="h-3.5 w-3.5 text-clay" /> Teman harian hidup sehat
          </p>
          <h1 className="rise mt-6 font-display text-[clamp(3rem,7.5vw,6.2rem)] font-light leading-[.95] tracking-tight text-forest [animation-delay:.1s]">
            Rawat tubuh,
            <br />
            <em className="font-normal text-clay">rawat</em> hidup<span className="text-clay">.</span>
          </h1>
          <p className="rise mt-7 max-w-lg text-lg leading-relaxed text-ink/70 [animation-delay:.2s]">
            Sehatara menyatukan kalkulator kesehatan, pelacak kebiasaan, jurnal dari para ahli, dan konsultasi dokter —
            dalam satu ruang yang tenang dan mudah dipahami.
          </p>
          <div className="rise mt-9 flex flex-wrap gap-3 [animation-delay:.3s]">
            <Link
              to="/alat"
              className="group inline-flex items-center gap-2 rounded-full bg-forest px-7 py-4 font-semibold text-cream transition hover:-translate-y-0.5 hover:shadow-[0_14px_30px_-12px_rgba(29,58,47,.7)]"
            >
              Mulai Cek Kesehatan
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
            </Link>
            <Link
              to="/konsultasi"
              className="inline-flex items-center gap-2 rounded-full border border-forest/20 px-7 py-4 font-semibold text-forest transition hover:bg-forest/5"
            >
              <Stethoscope className="h-4 w-4" /> Tanya Dokter
            </Link>
          </div>
          <div className="rise mt-12 flex items-center gap-4 [animation-delay:.4s]">
            <div className="flex -space-x-3">
              {['bg-clay', 'bg-butter', 'bg-sage', 'bg-moss'].map((c, i) => (
                <span key={c} className={`grid h-10 w-10 place-items-center rounded-full border-2 border-cream ${c} font-display text-sm text-forest`}>
                  {'ARNS'[i]}
                </span>
              ))}
            </div>
            <p className="text-sm text-ink/60">
              <strong className="text-forest">120.000+</strong> orang sudah memulai kebiasaan sehat
            </p>
          </div>
        </div>

        <div className="rise relative mx-auto w-full max-w-md [animation-delay:.25s]">
          <div className="relative aspect-[4/5] overflow-hidden rounded-t-[999px] rounded-b-[2.5rem] bg-sage shadow-[0_40px_80px_-30px_rgba(29,58,47,.55)]">
            <img src={img('hero.png', 900)} alt="Herba segar, air lemon, dan teh hijau" className="h-full w-full scale-110 object-cover" />
          </div>

          {/* Rotating badge */}
          <div className="absolute -left-8 top-10 grid h-28 w-28 place-items-center rounded-full bg-forest text-cream shadow-xl">
            <svg viewBox="0 0 100 100" className="absolute inset-0 animate-spin-slow">
              <defs>
                <path id="circle" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
              </defs>
              <text className="fill-cream text-[9.5px] font-semibold uppercase tracking-[.3em]">
                <textPath href="#circle">sehat · setiap · hari · sehatara ·</textPath>
              </text>
            </svg>
            <HeartPulse className="h-8 w-8 text-clay" />
          </div>

          {/* Heart rate card */}
          <div className="absolute -right-4 bottom-24 w-52 animate-float rounded-3xl bg-paper/90 p-4 shadow-xl backdrop-blur md:-right-10">
            <div className="flex items-center justify-between text-xs font-semibold text-ink/60">
              <span className="flex items-center gap-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inset-0 animate-pulse-ring rounded-full bg-clay" />
                  <span className="relative h-2 w-2 rounded-full bg-clay" />
                </span>
                Detak jantung
              </span>
              <span>live</span>
            </div>
            <p className="mt-1 font-display text-3xl text-forest">
              72 <span className="text-sm text-ink/50">bpm</span>
            </p>
            <svg viewBox="0 0 200 40" className="mt-1 h-10 w-full">
              <path
                className="heartline"
                d="M0 22 H50 L60 22 L68 6 L78 36 L86 14 L92 22 H130 L138 22 L144 10 L152 32 L158 22 H200"
                fill="none"
                stroke="#e0764f"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>

          {/* Water card */}
          <div className="absolute -bottom-6 left-4 flex animate-float items-center gap-3 rounded-3xl bg-forest p-4 pr-6 text-cream shadow-xl [animation-delay:-3s]">
            <div className="relative h-12 w-12 overflow-hidden rounded-2xl bg-cream/10">
              <div className="absolute inset-x-0 bottom-0 h-[68%] bg-sage/80">
                <svg viewBox="0 0 120 10" preserveAspectRatio="none" className="absolute -top-2 h-3 w-[200%] fill-sage/80" style={{ animation: 'wave 3s linear infinite' }}>
                  <path d="M0 5 Q15 0 30 5 T60 5 T90 5 T120 5 V10 H0Z" />
                </svg>
              </div>
            </div>
            <div>
              <p className="text-xs text-cream/60">Hidrasi hari ini</p>
              <p className="font-display text-xl">1,7 / 2,5 L</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function Marquee() {
  const words = ['Nutrisi seimbang', 'Tidur nyenyak', 'Gerak aktif', 'Pikiran tenang', 'Jantung kuat', 'Hidrasi cukup']
  return (
    <div className="relative -rotate-1 border-y border-forest/10 bg-forest py-5 text-cream">
      <div className="flex w-max animate-marquee gap-10 whitespace-nowrap">
        {[...words, ...words].map((w, i) => (
          <span key={i} className="flex items-center gap-10 font-display text-3xl italic">
            {w} <span className="text-clay not-italic">✺</span>
          </span>
        ))}
      </div>
    </div>
  )
}

const features = [
  { icon: Scale, title: 'Kalkulator BMI', text: 'Ketahui indeks massa tubuh dan rentang berat badan idealmu.', tool: 'bmi', span: 'md:col-span-2', tone: 'bg-butter' },
  { icon: Flame, title: 'Kebutuhan Kalori', text: 'Hitung BMR & TDEE sesuai aktivitas dan targetmu.', tool: 'kalori', span: '', tone: 'bg-paper' },
  { icon: Droplets, title: 'Pelacak Air', text: 'Pantau gelas demi gelas menuju target hidrasi harian.', tool: 'air', span: '', tone: 'bg-sage' },
  { icon: Wind, title: 'Latihan Napas', text: 'Ritme 4-7-8 terpandu untuk meredakan stres dalam 3 menit.', tool: 'napas', span: '', tone: 'bg-paper' },
  { icon: Activity, title: 'Zona Detak Jantung', text: 'Temukan zona latihan optimal berdasarkan usiamu.', tool: 'jantung', span: '', tone: 'bg-clay' },
  { icon: Moon, title: 'Jam Tidur Ideal', text: 'Hitung waktu tidur berdasarkan siklus 90 menit agar bangun segar.', tool: 'tidur', span: 'md:col-span-2', tone: 'bg-forest text-cream' },
] as const

function Features() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-28">
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[.2em] text-clay">Fitur unggulan</p>
            <h2 className="mt-3 max-w-xl font-display text-5xl font-light leading-tight text-forest md:text-6xl">
              Enam alat kecil, <em>dampak besar.</em>
            </h2>
          </div>
          <Link to="/alat" className="group inline-flex items-center gap-2 font-semibold text-forest">
            Lihat semua alat <ArrowUpRight className="h-4 w-4 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </Link>
        </div>
      </Reveal>
      <div className="mt-14 grid gap-4 md:grid-cols-4">
        {features.map((f, i) => (
          <Reveal key={f.title} delay={i * 80} className={f.span}>
            <Link
              to="/alat"
              hash={f.tool}
              className={`group relative flex h-full min-h-64 flex-col justify-between overflow-hidden rounded-[2rem] p-7 ring-1 ring-forest/10 transition duration-500 hover:-translate-y-1.5 hover:shadow-[0_30px_60px_-30px_rgba(29,58,47,.5)] ${f.tone}`}
            >
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-cream/70 text-forest transition duration-500 group-hover:rotate-[-8deg] group-hover:scale-110">
                <f.icon className="h-6 w-6" />
              </span>
              <div>
                <h3 className="font-display text-2xl">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed opacity-75">{f.text}</p>
              </div>
              <ArrowUpRight className="absolute right-6 top-6 h-5 w-5 opacity-0 transition duration-500 group-hover:opacity-100" />
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  )
}

const habits = [
  { label: 'Minum ≥ 8 gelas air', emoji: '💧' },
  { label: 'Tidur 7–9 jam', emoji: '🌙' },
  { label: 'Bergerak 30 menit', emoji: '🚶' },
  { label: 'Makan sayur & buah', emoji: '🥗' },
  { label: 'Waktu tenang tanpa layar', emoji: '🧘' },
]

function DailyCheck() {
  const [done, setDone] = useState<boolean[]>(habits.map(() => false))
  const score = Math.round((done.filter(Boolean).length / habits.length) * 100)
  const r = 70
  const c = 2 * Math.PI * r
  const message =
    score === 100 ? 'Sempurna! Kamu luar biasa hari ini 🌿' : score >= 60 ? 'Hebat, sedikit lagi menuju hari yang utuh.' : score > 0 ? 'Awal yang baik — satu kebiasaan lagi?' : 'Centang kebiasaan yang sudah kamu lakukan hari ini.'

  return (
    <section className="px-4">
      <Reveal>
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 overflow-hidden rounded-[2.5rem] bg-paper p-8 ring-1 ring-forest/10 md:grid-cols-2 md:p-14">
          <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 animate-blob bg-clay/15" />
          <div>
            <p className="text-xs font-semibold uppercase tracking-[.2em] text-clay">Cek harian · 30 detik</p>
            <h2 className="mt-3 font-display text-4xl font-light text-forest md:text-5xl">Seberapa sehat harimu?</h2>
            <ul className="mt-8 space-y-3">
              {habits.map((h, i) => (
                <li key={h.label}>
                  <button
                    onClick={() => setDone(done.map((d, j) => (j === i ? !d : d)))}
                    className={`flex w-full items-center gap-4 rounded-2xl px-5 py-4 text-left transition duration-300 ${
                      done[i] ? 'bg-forest text-cream' : 'bg-cream hover:bg-sage/30'
                    }`}
                  >
                    <span className={`grid h-7 w-7 place-items-center rounded-full border-2 transition ${done[i] ? 'border-butter bg-butter text-forest' : 'border-forest/25'}`}>
                      {done[i] && '✓'}
                    </span>
                    <span className="text-xl">{h.emoji}</span>
                    <span className="font-medium">{h.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div className="relative flex flex-col items-center text-center">
            <svg viewBox="0 0 180 180" className="h-64 w-64 -rotate-90">
              <circle cx="90" cy="90" r={r} fill="none" stroke="#1d3a2f15" strokeWidth="14" />
              <circle
                cx="90"
                cy="90"
                r={r}
                fill="none"
                stroke="#e0764f"
                strokeWidth="14"
                strokeLinecap="round"
                strokeDasharray={c}
                strokeDashoffset={c - (c * score) / 100}
                style={{ transition: 'stroke-dashoffset 1s cubic-bezier(.2,.7,.2,1)' }}
              />
            </svg>
            <div className="absolute top-0 grid h-64 w-64 place-items-center">
              <div>
                <p className="font-display text-6xl text-forest">{score}</p>
                <p className="text-xs font-semibold uppercase tracking-[.2em] text-ink/50">skor sehat</p>
              </div>
            </div>
            <p className="mt-6 max-w-xs text-ink/70">{message}</p>
          </div>
        </div>
      </Reveal>
    </section>
  )
}

function CountUp({ to, suffix = '' }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  const [value, setValue] = useState(0)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting) return
      io.disconnect()
      const start = performance.now()
      const tick = (t: number) => {
        const p = Math.min((t - start) / 1600, 1)
        setValue(Math.round(to * (1 - Math.pow(1 - p, 3))))
        if (p < 1) requestAnimationFrame(tick)
      }
      requestAnimationFrame(tick)
    })
    io.observe(el)
    return () => io.disconnect()
  }, [to])
  return (
    <span ref={ref}>
      {value.toLocaleString('id-ID')}
      {suffix}
    </span>
  )
}

function Stats() {
  const stats = [
    { n: 120, s: 'rb+', l: 'Pengguna aktif' },
    { n: 85, s: '+', l: 'Dokter & psikolog' },
    { n: 340, s: '+', l: 'Artikel terverifikasi' },
    { n: 98, s: '%', l: 'Merasa lebih sehat' },
  ]
  return (
    <section className="mx-auto grid max-w-6xl grid-cols-2 gap-y-12 px-6 py-28 md:grid-cols-4">
      {stats.map((s, i) => (
        <Reveal key={s.l} delay={i * 100} className="border-l border-forest/15 pl-6">
          <p className="font-display text-6xl font-light text-forest md:text-7xl">
            <CountUp to={s.n} suffix={s.s} />
          </p>
          <p className="mt-2 text-sm text-ink/60">{s.l}</p>
        </Reveal>
      ))}
    </section>
  )
}

function Journal() {
  const [first, ...rest] = articles
  return (
    <section className="mx-auto max-w-6xl px-6">
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <h2 className="font-display text-5xl font-light text-forest md:text-6xl">
            Dari <em className="text-clay">Jurnal</em>
          </h2>
          <Link to="/artikel" className="group inline-flex items-center gap-2 font-semibold text-forest">
            Semua artikel <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      </Reveal>
      <div className="mt-12 grid gap-6 lg:grid-cols-2">
        <Reveal>
          <Link to="/artikel/$slug" params={{ slug: first.slug }} className="group block">
            <div className="aspect-[4/3] overflow-hidden rounded-[2rem]">
              <img src={img(first.image, 900)} alt={first.title} className="h-full w-full object-cover transition duration-[1.2s] group-hover:scale-105" loading="lazy" />
            </div>
            <p className="mt-5 text-xs font-semibold uppercase tracking-[.2em] text-clay">{first.category}</p>
            <h3 className="mt-2 font-display text-3xl text-forest group-hover:underline group-hover:decoration-clay group-hover:underline-offset-4">{first.title}</h3>
            <p className="mt-2 text-ink/65">{first.excerpt}</p>
          </Link>
        </Reveal>
        <div className="flex flex-col gap-6">
          {rest.slice(0, 3).map((a, i) => (
            <Reveal key={a.slug} delay={i * 100}>
              <Link to="/artikel/$slug" params={{ slug: a.slug }} className="group grid grid-cols-[8rem_1fr] items-center gap-5 rounded-[1.5rem] p-2 transition hover:bg-paper sm:grid-cols-[11rem_1fr]">
                <div className="aspect-square overflow-hidden rounded-[1.25rem]">
                  <img src={img(a.image, 400)} alt={a.title} className="h-full w-full object-cover transition duration-700 group-hover:scale-110" loading="lazy" />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[.2em] text-clay">
                    {a.category} · {a.readMinutes} mnt
                  </p>
                  <h3 className="mt-1.5 font-display text-xl leading-snug text-forest">{a.title}</h3>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

const testimonials = [
  { q: 'Pelacak airnya bikin aku sadar ternyata selama ini kurang minum. Sekarang jarang sakit kepala lagi.', n: 'Rina, 27', r: 'Desainer, Bandung' },
  { q: 'Latihan napas 4-7-8 jadi ritual sebelum tidur. Tidurku jauh lebih nyenyak.', n: 'Andi, 34', r: 'Engineer, Jakarta' },
  { q: 'Konsultasi dengan ahli gizinya sangat ramah dan jelas. Berat badanku turun 6 kg dengan cara sehat.', n: 'Siti, 41', r: 'Guru, Surabaya' },
]

function Testimonials() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-28">
      <div className="grid gap-6 md:grid-cols-3">
        {testimonials.map((t, i) => (
          <Reveal key={t.n} delay={i * 120}>
            <figure className={`flex h-full flex-col justify-between rounded-[2rem] p-8 ${i === 1 ? 'bg-forest text-cream md:-translate-y-8' : 'bg-paper ring-1 ring-forest/10'}`}>
              <div>
                <div className="flex gap-1 text-butter">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <blockquote className="mt-5 font-display text-xl leading-relaxed">“{t.q}”</blockquote>
              </div>
              <figcaption className="mt-8 text-sm">
                <strong>{t.n}</strong>
                <span className="opacity-60"> — {t.r}</span>
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>
    </section>
  )
}

function Cta() {
  return (
    <section className="px-4">
      <Reveal>
        <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2.5rem] bg-clay px-8 py-20 text-center text-cream md:py-28">
          <div className="pointer-events-none absolute -left-20 -top-20 h-72 w-72 animate-blob bg-butter/40" />
          <div className="pointer-events-none absolute -bottom-24 -right-10 h-80 w-80 animate-blob bg-forest/30 [animation-delay:-8s]" />
          <h2 className="relative mx-auto max-w-3xl font-display text-5xl font-light leading-tight md:text-7xl">
            Langkah kecil hari ini, <em>versi terbaikmu</em> esok hari.
          </h2>
          <div className="relative mt-10 flex flex-wrap justify-center gap-3">
            <Link to="/alat" className="rounded-full bg-cream px-8 py-4 font-semibold text-forest transition hover:-translate-y-0.5">
              Coba Alat Sehat
            </Link>
            <Link to="/konsultasi" className="rounded-full border border-cream/50 px-8 py-4 font-semibold transition hover:bg-cream/10">
              Buat Janji Dokter
            </Link>
          </div>
        </div>
      </Reveal>
    </section>
  )
}
