import { createFileRoute } from '@tanstack/react-router'
import { Activity, Droplets, Flame, Moon, Scale, Wind } from 'lucide-react'
import { Reveal } from '@/components/Reveal'
import { BmiTool, BreathTool, CalorieTool, HeartTool, SleepTool, ToolCard, WaterTool } from '@/components/tools'

export const Route = createFileRoute('/alat')({
  head: () => ({ meta: [{ title: 'Alat Sehat — Sehatara' }] }),
  component: Tools,
})

const tools = [
  { id: 'bmi', label: 'BMI', icon: Scale },
  { id: 'kalori', label: 'Kalori', icon: Flame },
  { id: 'air', label: 'Air', icon: Droplets },
  { id: 'napas', label: 'Napas', icon: Wind },
  { id: 'jantung', label: 'Jantung', icon: Activity },
  { id: 'tidur', label: 'Tidur', icon: Moon },
]

function Tools() {
  return (
    <div className="pt-32 md:pt-40">
      <section className="mx-auto max-w-6xl px-6">
        <p className="rise text-xs font-semibold uppercase tracking-[.2em] text-clay">Alat Sehat</p>
        <h1 className="rise mt-3 max-w-3xl font-display text-6xl font-light leading-[.95] text-forest [animation-delay:.1s] md:text-8xl">
          Kenali tubuhmu, <em className="text-clay">angka demi angka.</em>
        </h1>
        <p className="rise mt-6 max-w-xl text-lg text-ink/65 [animation-delay:.2s]">
          Enam alat sederhana berbasis standar medis. Geser, ketuk, dan lihat hasilnya seketika.
        </p>
      </section>

      <nav className="sticky top-24 z-40 mx-auto mt-12 max-w-6xl px-4">
        <div className="flex gap-1 overflow-x-auto rounded-full bg-paper/85 p-1.5 shadow-[0_10px_30px_-15px_rgba(29,58,47,.4)] ring-1 ring-forest/10 backdrop-blur-xl">
          {tools.map((t) => (
            <a key={t.id} href={`#${t.id}`} className="flex shrink-0 items-center gap-2 rounded-full px-4 py-2.5 text-sm font-medium text-forest/70 transition hover:bg-forest hover:text-cream">
              <t.icon className="h-4 w-4" /> {t.label}
            </a>
          ))}
        </div>
      </nav>

      <div className="mx-auto mt-10 max-w-6xl space-y-8 px-4">
        <Reveal><ToolCard id="bmi" eyebrow="01 · Komposisi tubuh" title="Kalkulator BMI" desc="Indeks massa tubuh membandingkan berat dan tinggi badan untuk memperkirakan status gizi orang dewasa."><BmiTool /></ToolCard></Reveal>
        <Reveal><ToolCard id="kalori" eyebrow="02 · Energi" title="Kebutuhan Kalori Harian" desc="Dihitung dengan rumus Mifflin-St Jeor, lengkap dengan pembagian makronutrien yang seimbang."><CalorieTool /></ToolCard></Reveal>
        <Reveal><ToolCard id="air" eyebrow="03 · Hidrasi" title="Pelacak Minum Air" desc="Ketuk gelas setiap kali kamu minum. Target dihitung 33 ml per kilogram berat badan."><WaterTool /></ToolCard></Reveal>
        <Reveal><ToolCard id="napas" eyebrow="04 · Ketenangan" title="Latihan Napas 4-7-8" desc="Ikuti lingkaran yang mengembang dan mengempis. Cocok sebelum tidur atau saat merasa cemas."><BreathTool /></ToolCard></Reveal>
        <Reveal><ToolCard id="jantung" eyebrow="05 · Kebugaran" title="Zona Detak Jantung" desc="Latih jantung di zona yang tepat sesuai tujuanmu — dari membakar lemak hingga meningkatkan stamina."><HeartTool /></ToolCard></Reveal>
        <Reveal><ToolCard id="tidur" eyebrow="06 · Istirahat" title="Kalkulator Jam Tidur" desc="Bangun di akhir siklus tidur agar terasa segar, bukan pusing."><SleepTool /></ToolCard></Reveal>
        <p className="px-4 text-center text-xs text-ink/50">Hasil alat ini bersifat perkiraan untuk edukasi dan tidak menggantikan pemeriksaan tenaga kesehatan.</p>
      </div>
    </div>
  )
}
