import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { ArrowLeft, Check, Clock } from 'lucide-react'
import { useEffect, useState } from 'react'
import articles from '@/data/articles'
import { img } from '@/lib/img'

export const Route = createFileRoute('/artikel/$slug')({
  loader: ({ params }) => {
    const article = articles.find((a) => a.slug === params.slug)
    if (!article) throw notFound()
    return article
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.title ?? 'Artikel'} — Sehatara` }, { name: 'description', content: loaderData?.excerpt }],
  }),
  component: ArticlePage,
  notFoundComponent: () => (
    <div className="px-6 pt-48 pb-24 text-center">
      <h1 className="font-display text-5xl text-forest">Artikel tidak ditemukan</h1>
      <Link to="/artikel" className="mt-6 inline-block font-semibold text-clay">← Kembali ke Jurnal</Link>
    </div>
  ),
})

function ArticlePage() {
  const a = Route.useLoaderData()
  const [progress, setProgress] = useState(0)
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement
      setProgress(h.scrollTop / Math.max(h.scrollHeight - h.clientHeight, 1))
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])
  const related = articles.filter((x) => x.slug !== a.slug).slice(0, 2)

  return (
    <article className="pt-32 md:pt-40">
      <div className="fixed inset-x-0 top-0 z-[70] h-1 origin-left bg-clay" style={{ transform: `scaleX(${progress})` }} />
      <div className="mx-auto max-w-3xl px-6">
        <Link to="/artikel" className="inline-flex items-center gap-2 text-sm font-semibold text-moss hover:text-clay">
          <ArrowLeft className="h-4 w-4" /> Jurnal
        </Link>
        <p className="rise mt-8 text-xs font-semibold uppercase tracking-[.2em] text-clay">{a.category}</p>
        <h1 className="rise mt-3 font-display text-5xl font-light leading-[1.05] text-forest [animation-delay:.1s] md:text-6xl">{a.title}</h1>
        <div className="rise mt-6 flex flex-wrap items-center gap-4 text-sm text-ink/60 [animation-delay:.2s]">
          <span className="font-semibold text-forest">{a.author}</span>
          <span>·</span>
          <span>{a.date}</span>
          <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {a.readMinutes} menit</span>
        </div>
      </div>
      <div className="rise mx-auto mt-12 max-w-5xl px-4 [animation-delay:.25s]">
        <div className="aspect-[16/9] overflow-hidden rounded-[2.5rem]">
          <img src={img(a.image, 1400)} alt={a.title} className="h-full w-full object-cover" />
        </div>
      </div>
      <div className="mx-auto mt-14 max-w-2xl px-6">
        {a.body.map((b, i) => (
          <div key={i} className="mb-8">
            {b.heading && <h2 className="mb-3 font-display text-3xl text-forest">{b.heading}</h2>}
            <p className={`leading-[1.9] text-ink/80 ${i === 0 ? 'text-xl first-letter:float-left first-letter:mr-3 first-letter:font-display first-letter:text-7xl first-letter:leading-[.8] first-letter:text-clay' : 'text-lg'}`}>
              {b.text}
            </p>
          </div>
        ))}
        <aside className="mt-12 rounded-[2rem] bg-forest p-8 text-cream">
          <h3 className="font-display text-2xl">Coba mulai hari ini</h3>
          <ul className="mt-5 space-y-3">
            {a.tips.map((t) => (
              <li key={t} className="flex gap-3">
                <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-butter text-forest"><Check className="h-3.5 w-3.5" /></span>
                {t}
              </li>
            ))}
          </ul>
        </aside>
      </div>
      <div className="mx-auto mt-20 max-w-5xl px-6">
        <h3 className="font-display text-3xl text-forest">Bacaan lainnya</h3>
        <div className="mt-6 grid gap-6 md:grid-cols-2">
          {related.map((r) => (
            <Link key={r.slug} to="/artikel/$slug" params={{ slug: r.slug }} className="group flex items-center gap-5 rounded-[1.5rem] bg-paper p-3 ring-1 ring-forest/10">
              <img src={img(r.image, 300)} alt="" className="h-24 w-24 rounded-2xl object-cover" loading="lazy" />
              <p className="font-display text-xl text-forest group-hover:text-clay">{r.title}</p>
            </Link>
          ))}
        </div>
      </div>
    </article>
  )
}
