import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Search } from 'lucide-react'
import { Reveal } from '@/components/Reveal'
import articles from '@/data/articles'
import { img } from '@/lib/img'

export const Route = createFileRoute('/artikel/')({
  head: () => ({ meta: [{ title: 'Jurnal Kesehatan — Sehatara' }] }),
  component: Journal,
})

const categories = ['Semua', 'Nutrisi', 'Tidur', 'Gerak', 'Mental', 'Jantung'] as const

function Journal() {
  const [cat, setCat] = useState<(typeof categories)[number]>('Semua')
  const [q, setQ] = useState('')
  const list = articles.filter(
    (a) => (cat === 'Semua' || a.category === cat) && (a.title + a.excerpt).toLowerCase().includes(q.toLowerCase()),
  )

  return (
    <div className="mx-auto max-w-6xl px-6 pt-32 md:pt-40">
      <h1 className="rise font-display text-6xl font-light text-forest md:text-8xl">
        Jurnal <em className="text-clay">Sehatara</em>
      </h1>
      <p className="rise mt-5 max-w-xl text-lg text-ink/65 [animation-delay:.1s]">
        Bacaan singkat yang ditulis dan ditinjau oleh dokter, ahli gizi, dan psikolog.
      </p>

      <div className="rise mt-10 flex flex-col gap-4 [animation-delay:.2s] md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`rounded-full px-5 py-2 text-sm font-medium transition ${cat === c ? 'bg-forest text-cream' : 'bg-paper text-forest ring-1 ring-forest/10 hover:bg-sage/30'}`}
            >
              {c}
            </button>
          ))}
        </div>
        <label className="flex items-center gap-2 rounded-full bg-paper px-4 py-2.5 ring-1 ring-forest/10 focus-within:ring-clay">
          <Search className="h-4 w-4 text-ink/40" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari artikel…" className="w-48 bg-transparent text-sm outline-none" />
        </label>
      </div>

      <div className="mt-12 grid gap-x-6 gap-y-14 md:grid-cols-2 lg:grid-cols-3">
        {list.map((a, i) => (
          <Reveal key={a.slug} delay={(i % 3) * 100}>
            <Link to="/artikel/$slug" params={{ slug: a.slug }} className="group block">
              <div className={`overflow-hidden rounded-[2rem] ${i % 3 === 1 ? 'aspect-[4/5]' : 'aspect-[4/4]'}`}>
                <img src={img(a.image, 700)} alt={a.title} loading="lazy" className="h-full w-full object-cover transition duration-[1.2s] group-hover:scale-105" />
              </div>
              <p className="mt-5 text-xs font-semibold uppercase tracking-[.2em] text-clay">
                {a.category} · {a.readMinutes} menit baca
              </p>
              <h2 className="mt-2 font-display text-2xl leading-snug text-forest">{a.title}</h2>
              <p className="mt-2 text-sm text-ink/60">{a.excerpt}</p>
            </Link>
          </Reveal>
        ))}
      </div>
      {list.length === 0 && <p className="py-20 text-center text-ink/50">Belum ada artikel yang cocok. Coba kata kunci lain.</p>}
    </div>
  )
}
