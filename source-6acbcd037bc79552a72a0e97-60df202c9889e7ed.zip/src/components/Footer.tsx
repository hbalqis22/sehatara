import { Link } from '@tanstack/react-router'
import { Logo } from './Logo'

export function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden bg-forest text-cream">
      <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 animate-blob bg-moss/60" />
      <div className="relative mx-auto grid max-w-6xl gap-12 px-6 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo light />
          <p className="mt-5 max-w-sm text-cream/70">
            Teman harian untuk hidup lebih sehat — alat ukur, jurnal tepercaya, dan konsultasi dengan tenaga kesehatan profesional.
          </p>
        </div>
        <div>
          <h4 className="mb-4 text-xs font-semibold uppercase tracking-[.2em] text-sage">Jelajahi</h4>
          <ul className="space-y-2 text-cream/80">
            <li><Link to="/alat" className="hover:text-butter">Alat Sehat</Link></li>
            <li><Link to="/artikel" className="hover:text-butter">Jurnal Kesehatan</Link></li>
            <li><Link to="/konsultasi" className="hover:text-butter">Konsultasi Dokter</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-xs font-semibold uppercase tracking-[.2em] text-sage">Darurat</h4>
          <p className="font-display text-5xl text-butter">119</p>
          <p className="mt-1 text-sm text-cream/60">Layanan gawat darurat nasional, 24 jam.</p>
        </div>
      </div>
      <div className="relative border-t border-cream/10">
        <p className="mx-auto max-w-6xl px-6 py-6 text-xs text-cream/50">
          © {new Date().getFullYear()} Sehatara. Informasi di situs ini bersifat edukatif dan tidak menggantikan diagnosis dokter.
        </p>
      </div>
    </footer>
  )
}
