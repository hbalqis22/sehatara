import { Link } from '@tanstack/react-router'
import { Menu, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Logo } from './Logo'

const nav = [
  { to: '/', label: 'Beranda' },
  { to: '/alat', label: 'Alat Sehat' },
  { to: '/artikel', label: 'Jurnal' },
  { to: '/konsultasi', label: 'Konsultasi' },
] as const

export function Header() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-4 pt-4">
      <div
        className={`mx-auto flex max-w-6xl items-center justify-between rounded-full px-5 py-2.5 transition-all duration-500 ${
          scrolled ? 'bg-paper/80 shadow-[0_8px_30px_-12px_rgba(29,58,47,.35)] backdrop-blur-xl' : 'bg-transparent'
        }`}
      >
        <Link to="/" onClick={() => setOpen(false)}>
          <Logo />
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === '/' }}
              className="rounded-full px-4 py-2 text-sm font-medium text-forest/75 transition hover:text-forest"
              activeProps={{ className: '!text-forest bg-forest/8 ring-1 ring-forest/10' }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <Link
          to="/konsultasi"
          className="hidden rounded-full bg-forest px-5 py-2.5 text-sm font-semibold text-cream transition hover:-translate-y-0.5 hover:bg-moss md:inline-block"
        >
          Buat Janji
        </Link>
        <button className="rounded-full p-2 text-forest md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      <div
        className={`mx-auto mt-2 max-w-6xl overflow-hidden rounded-3xl bg-forest text-cream transition-all duration-500 md:hidden ${
          open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <nav className="flex flex-col p-4">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="rounded-2xl px-4 py-3 font-display text-2xl hover:bg-moss">
              {n.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  )
}
