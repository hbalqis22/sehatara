export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <svg viewBox="0 0 40 40" className="h-9 w-9" aria-hidden>
        <circle cx="20" cy="20" r="19" className={light ? 'fill-cream' : 'fill-forest'} />
        <path
          d="M20 30c-6-4-9-8-9-12a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 4-3 8-9 12Z"
          className="fill-clay"
        />
        <path d="M20 15c0 5 0 10 0 15M20 21c2-2 4-3 6-3" className={light ? 'stroke-forest' : 'stroke-cream'} strokeWidth="1.6" fill="none" strokeLinecap="round" />
      </svg>
      <span className={`font-display text-2xl font-semibold tracking-tight ${light ? 'text-cream' : 'text-forest'}`}>
        Sehatara<span className="text-clay">.</span>
      </span>
    </span>
  )
}
