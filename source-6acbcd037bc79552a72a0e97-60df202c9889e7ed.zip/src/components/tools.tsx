import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { Minus, Pause, Play, Plus, RotateCcw } from 'lucide-react'

const nf = (n: number, d = 0) => n.toLocaleString('id-ID', { maximumFractionDigits: d, minimumFractionDigits: d })

function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  unit,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  step?: number
  unit: string
  onChange: (v: number) => void
}) {
  return (
    <label className="block">
      <div className="flex items-baseline justify-between">
        <span className="text-sm font-medium text-ink/70">{label}</span>
        <span className="font-display text-2xl text-forest">
          {nf(value, step < 1 ? 1 : 0)} <span className="text-sm text-ink/50">{unit}</span>
        </span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} className="mt-2 w-full" />
    </label>
  )
}

function Segmented<T extends string>({ options, value, onChange }: { options: { v: T; l: string }[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="flex flex-wrap gap-1 rounded-2xl bg-cream p-1">
      {options.map((o) => (
        <button
          key={o.v}
          onClick={() => onChange(o.v)}
          className={`flex-1 rounded-xl px-3 py-2 text-sm font-medium transition ${value === o.v ? 'bg-forest text-cream shadow' : 'text-ink/60 hover:text-forest'}`}
        >
          {o.l}
        </button>
      ))}
    </div>
  )
}

export function ToolCard({ id, eyebrow, title, desc, children }: { id: string; eyebrow: string; title: string; desc: string; children: ReactNode }) {
  return (
    <section id={id} className="scroll-mt-32 rounded-[2.5rem] bg-paper p-6 ring-1 ring-forest/10 md:p-12">
      <p className="text-xs font-semibold uppercase tracking-[.2em] text-clay">{eyebrow}</p>
      <h2 className="mt-2 font-display text-4xl font-light text-forest md:text-5xl">{title}</h2>
      <p className="mt-3 max-w-xl text-ink/65">{desc}</p>
      <div className="mt-10">{children}</div>
    </section>
  )
}

/* ---------- BMI ---------- */
const bmiBands = [
  { max: 18.5, label: 'Berat badan kurang', color: '#a9c4a4', tip: 'Tambah asupan kalori bergizi seperti kacang, alpukat, dan protein.' },
  { max: 25, label: 'Normal', color: '#3f6b52', tip: 'Pertahankan! Pola makan dan aktivitasmu sudah seimbang.' },
  { max: 30, label: 'Berat badan berlebih', color: '#f2cc7f', tip: 'Kurangi gula dan gorengan, tambah aktivitas fisik 150 menit/minggu.' },
  { max: 99, label: 'Obesitas', color: '#e0764f', tip: 'Konsultasikan dengan dokter atau ahli gizi untuk program yang aman.' },
]

export function BmiTool() {
  const [h, setH] = useState(165)
  const [w, setW] = useState(60)
  const bmi = w / (h / 100) ** 2
  const band = bmiBands.find((b) => bmi < b.max)!
  const pos = Math.min(Math.max(((bmi - 15) / (40 - 15)) * 100, 0), 100)
  const ideal = [18.5 * (h / 100) ** 2, 24.9 * (h / 100) ** 2]

  return (
    <div className="grid gap-10 md:grid-cols-2">
      <div className="space-y-8">
        <Slider label="Tinggi badan" value={h} min={120} max={210} unit="cm" onChange={setH} />
        <Slider label="Berat badan" value={w} min={30} max={160} unit="kg" onChange={setW} />
      </div>
      <div className="rounded-[2rem] bg-cream p-8">
        <p className="text-sm text-ink/60">Indeks massa tubuhmu</p>
        <p className="font-display text-7xl font-light text-forest">{nf(bmi, 1)}</p>
        <p className="mt-1 inline-block rounded-full px-3 py-1 text-sm font-semibold text-forest" style={{ background: band.color + '55' }}>
          {band.label}
        </p>
        <div className="relative mt-8 h-3 rounded-full" style={{ background: 'linear-gradient(90deg,#a9c4a4 0 14%,#3f6b52 14% 40%,#f2cc7f 40% 60%,#e0764f 60%)' }}>
          <span className="absolute -top-1.5 h-6 w-6 -translate-x-1/2 rounded-full border-4 border-cream bg-forest shadow transition-all duration-500" style={{ left: `${pos}%` }} />
        </div>
        <div className="mt-2 flex justify-between text-[11px] text-ink/45">
          <span>15</span><span>18,5</span><span>25</span><span>30</span><span>40</span>
        </div>
        <p className="mt-6 text-sm text-ink/70">
          Berat ideal untuk tinggimu: <strong className="text-forest">{nf(ideal[0])}–{nf(ideal[1])} kg</strong>
        </p>
        <p className="mt-2 text-sm text-ink/70">{band.tip}</p>
      </div>
    </div>
  )
}

/* ---------- Calories ---------- */
const activity = [
  { v: '1.2', l: 'Jarang' },
  { v: '1.375', l: 'Ringan' },
  { v: '1.55', l: 'Sedang' },
  { v: '1.725', l: 'Aktif' },
] as const

export function CalorieTool() {
  const [sex, setSex] = useState<'p' | 'w'>('w')
  const [age, setAge] = useState(28)
  const [h, setH] = useState(160)
  const [w, setW] = useState(55)
  const [act, setAct] = useState<(typeof activity)[number]['v']>('1.375')
  const bmr = 10 * w + 6.25 * h - 5 * age + (sex === 'p' ? 5 : -161)
  const tdee = bmr * +act
  const goals = [
    { l: 'Turun berat', v: tdee - 500, c: 'bg-sage' },
    { l: 'Pertahankan', v: tdee, c: 'bg-butter' },
    { l: 'Naik berat', v: tdee + 400, c: 'bg-clay text-cream' },
  ]
  const macros = [
    { l: 'Karbohidrat', p: 50, kcal: 4, c: '#f2cc7f' },
    { l: 'Protein', p: 20, kcal: 4, c: '#e0764f' },
    { l: 'Lemak', p: 30, kcal: 9, c: '#3f6b52' },
  ]
  return (
    <div className="grid gap-10 md:grid-cols-2">
      <div className="space-y-7">
        <Segmented options={[{ v: 'w', l: 'Perempuan' }, { v: 'p', l: 'Laki-laki' }]} value={sex} onChange={setSex} />
        <Slider label="Usia" value={age} min={15} max={80} unit="thn" onChange={setAge} />
        <Slider label="Tinggi" value={h} min={130} max={210} unit="cm" onChange={setH} />
        <Slider label="Berat" value={w} min={35} max={150} unit="kg" onChange={setW} />
        <div>
          <p className="mb-2 text-sm font-medium text-ink/70">Tingkat aktivitas</p>
          <Segmented options={[...activity]} value={act} onChange={setAct} />
        </div>
      </div>
      <div className="space-y-4">
        <div className="rounded-[2rem] bg-forest p-8 text-cream">
          <p className="text-sm text-cream/60">Kebutuhan energi harian (TDEE)</p>
          <p className="font-display text-6xl font-light">
            {nf(tdee)} <span className="text-lg text-cream/60">kkal</span>
          </p>
          <p className="mt-1 text-sm text-cream/60">BMR (energi saat istirahat): {nf(bmr)} kkal</p>
          <div className="mt-6 space-y-3">
            {macros.map((m) => (
              <div key={m.l}>
                <div className="flex justify-between text-sm">
                  <span>{m.l}</span>
                  <span className="text-cream/70">{nf((tdee * m.p) / 100 / m.kcal)} g</span>
                </div>
                <div className="mt-1 h-2 rounded-full bg-cream/10">
                  <div className="h-2 rounded-full transition-all duration-700" style={{ width: `${m.p * 1.6}%`, background: m.c }} />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {goals.map((g) => (
            <div key={g.l} className={`rounded-2xl p-4 ${g.c}`}>
              <p className="text-xs opacity-75">{g.l}</p>
              <p className="font-display text-2xl">{nf(g.v)}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ---------- Water ---------- */
const todayKey = () => `sehatara-air-${new Date().toISOString().slice(0, 10)}`

export function WaterTool() {
  const [weight, setWeight] = useState(60)
  const [glasses, setGlasses] = useState(0)
  const target = Math.round((weight * 33) / 250) // gelas 250 ml
  useEffect(() => {
    const saved = localStorage.getItem(todayKey())
    if (saved) setGlasses(+saved)
  }, [])
  useEffect(() => {
    localStorage.setItem(todayKey(), String(glasses))
  }, [glasses])
  const pct = Math.min(glasses / target, 1)

  return (
    <div className="grid items-center gap-10 md:grid-cols-[auto_1fr]">
      <div className="relative mx-auto h-80 w-52 overflow-hidden rounded-b-[3rem] rounded-t-2xl border-4 border-forest/15 bg-cream">
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-moss to-sage transition-all duration-1000 ease-out" style={{ height: `${pct * 100}%` }}>
          <svg viewBox="0 0 120 10" preserveAspectRatio="none" className="absolute -top-3 h-4 w-[200%] fill-sage" style={{ animation: 'wave 2.5s linear infinite' }}>
            <path d="M0 5 Q15 0 30 5 T60 5 T90 5 T120 5 V10 H0Z" />
          </svg>
        </div>
        <div className="absolute inset-0 grid place-items-center">
          <div className="text-center">
            <p className="font-display text-5xl text-forest mix-blend-multiply">{Math.round(pct * 100)}%</p>
            <p className="text-sm text-forest/70">{nf((glasses * 250) / 1000, 2)} L</p>
          </div>
        </div>
      </div>
      <div>
        <Slider label="Berat badan" value={weight} min={30} max={150} unit="kg" onChange={setWeight} />
        <p className="mt-6 text-ink/70">
          Target harianmu: <strong className="text-forest">{target} gelas</strong> ({nf((target * 250) / 1000, 1)} L)
        </p>
        <div className="mt-6 flex flex-wrap gap-2">
          {Array.from({ length: target }).map((_, i) => (
            <button
              key={i}
              onClick={() => setGlasses(i + 1 === glasses ? i : i + 1)}
              aria-label={`Gelas ${i + 1}`}
              className={`h-12 w-9 rounded-b-xl rounded-t-sm border-2 transition duration-300 hover:-translate-y-1 ${
                i < glasses ? 'border-moss bg-sage' : 'border-forest/20 bg-cream'
              }`}
            />
          ))}
        </div>
        <div className="mt-6 flex items-center gap-3">
          <button onClick={() => setGlasses(Math.max(0, glasses - 1))} className="grid h-12 w-12 place-items-center rounded-full ring-1 ring-forest/20 hover:bg-cream" aria-label="Kurangi">
            <Minus className="h-5 w-5" />
          </button>
          <button onClick={() => setGlasses(glasses + 1)} className="inline-flex items-center gap-2 rounded-full bg-forest px-6 py-3 font-semibold text-cream transition hover:bg-moss">
            <Plus className="h-5 w-5" /> Tambah segelas
          </button>
          <button onClick={() => setGlasses(0)} className="grid h-12 w-12 place-items-center rounded-full ring-1 ring-forest/20 hover:bg-cream" aria-label="Atur ulang">
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
        <p className="mt-4 text-xs text-ink/50">Progres tersimpan di perangkat ini dan diatur ulang setiap hari.</p>
      </div>
    </div>
  )
}

/* ---------- Breathing ---------- */
const phases = [
  { name: 'Tarik napas', secs: 4, scale: 1 },
  { name: 'Tahan', secs: 7, scale: 1 },
  { name: 'Hembuskan', secs: 8, scale: 0.45 },
]

export function BreathTool() {
  const [running, setRunning] = useState(false)
  const [{ phase, left, cycles }, setState] = useState({ phase: 0, left: phases[0].secs, cycles: 0 })

  useEffect(() => {
    if (!running) return
    const id = setInterval(() => {
      setState((s) => {
        if (s.left > 1) return { ...s, left: s.left - 1 }
        const next = (s.phase + 1) % phases.length
        return { phase: next, left: phases[next].secs, cycles: s.cycles + (next === 0 ? 1 : 0) }
      })
    }, 1000)
    return () => clearInterval(id)
  }, [running])

  const current = phases[phase]
  const scale = running ? current.scale : 0.45

  return (
    <div className="grid items-center gap-10 md:grid-cols-2">
      <div className="relative mx-auto grid h-80 w-80 place-items-center">
        <div className="absolute inset-0 rounded-full border border-dashed border-forest/20" />
        <div
          className="absolute inset-4 rounded-full bg-gradient-to-br from-sage to-moss opacity-90 shadow-[0_0_80px_-10px_#3f6b52]"
          style={{ transform: `scale(${scale})`, transition: `transform ${running ? current.secs : 0.6}s cubic-bezier(.45,0,.55,1)` }}
        />
        <div className="relative text-center text-cream">
          <p className="font-display text-2xl">{running ? current.name : 'Siap?'}</p>
          {running && <p className="font-display text-6xl">{left}</p>}
        </div>
      </div>
      <div>
        <p className="leading-relaxed text-ink/70">
          Teknik 4-7-8 membantu menenangkan sistem saraf. Tarik napas lewat hidung selama <strong>4 detik</strong>, tahan{' '}
          <strong>7 detik</strong>, lalu hembuskan perlahan lewat mulut selama <strong>8 detik</strong>. Ulangi 4 siklus.
        </p>
        <div className="mt-6 flex gap-3">
          {phases.map((p, i) => (
            <div key={p.name} className={`flex-1 rounded-2xl p-4 transition ${running && phase === i ? 'bg-forest text-cream' : 'bg-cream'}`}>
              <p className="font-display text-3xl">{p.secs}</p>
              <p className="text-xs opacity-70">{p.name}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 flex items-center gap-4">
          <button
            onClick={() => {
              if (!running) setState((s) => ({ ...s, phase: 0, left: phases[0].secs }))
              setRunning(!running)
            }}
            className="inline-flex items-center gap-2 rounded-full bg-clay px-7 py-3.5 font-semibold text-cream transition hover:-translate-y-0.5"
          >
            {running ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />} {running ? 'Jeda' : 'Mulai latihan'}
          </button>
          <span className="text-sm text-ink/60">Siklus selesai: <strong className="text-forest">{cycles}</strong></span>
        </div>
      </div>
    </div>
  )
}

/* ---------- Heart rate zones ---------- */
const zones = [
  { n: 'Pemanasan', lo: 0.5, hi: 0.6, c: '#a9c4a4', d: 'Pemulihan & jalan santai' },
  { n: 'Bakar lemak', lo: 0.6, hi: 0.7, c: '#3f6b52', d: 'Daya tahan dasar' },
  { n: 'Aerobik', lo: 0.7, hi: 0.8, c: '#f2cc7f', d: 'Kebugaran jantung-paru' },
  { n: 'Anaerobik', lo: 0.8, hi: 0.9, c: '#e0764f', d: 'Kecepatan & kekuatan' },
  { n: 'Maksimal', lo: 0.9, hi: 1, c: '#b5482a', d: 'Sprint singkat' },
]

export function HeartTool() {
  const [age, setAge] = useState(30)
  const [rest, setRest] = useState(70)
  const max = 220 - age
  const reserve = max - rest
  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.3fr]">
      <div className="space-y-8">
        <Slider label="Usia" value={age} min={15} max={85} unit="thn" onChange={setAge} />
        <Slider label="Detak istirahat" value={rest} min={40} max={100} unit="bpm" onChange={setRest} />
        <div className="rounded-2xl bg-cream p-5">
          <p className="text-sm text-ink/60">Detak jantung maksimal</p>
          <p className="font-display text-5xl text-forest">{max} <span className="text-base text-ink/50">bpm</span></p>
        </div>
      </div>
      <div className="space-y-3">
        {zones.map((z, i) => {
          const lo = Math.round(rest + reserve * z.lo)
          const hi = Math.round(rest + reserve * z.hi)
          return (
            <div key={z.n} className="group flex items-center gap-4 rounded-2xl bg-cream p-4 transition hover:translate-x-1">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl font-display text-xl text-cream" style={{ background: z.c }}>
                {i + 1}
              </span>
              <div className="flex-1">
                <div className="flex justify-between">
                  <p className="font-semibold text-forest">{z.n}</p>
                  <p className="font-display text-lg text-forest">{lo}–{hi}</p>
                </div>
                <div className="mt-1 flex justify-between text-xs text-ink/55">
                  <span>{z.d}</span>
                  <span>{Math.round(z.lo * 100)}–{Math.round(z.hi * 100)}%</span>
                </div>
              </div>
            </div>
          )
        })}
        <p className="pt-2 text-xs text-ink/50">Dihitung dengan metode Karvonen (cadangan detak jantung).</p>
      </div>
    </div>
  )
}

/* ---------- Sleep cycles ---------- */
export function SleepTool() {
  const [wake, setWake] = useState('06:00')
  const times = useMemo(() => {
    const [hh, mm] = wake.split(':').map(Number)
    const base = hh * 60 + mm - 15 // 15 menit untuk terlelap
    return [6, 5, 4].map((cycles) => {
      let t = (base - cycles * 90) % 1440
      if (t < 0) t += 1440
      return { cycles, hours: (cycles * 90) / 60, at: `${String(Math.floor(t / 60)).padStart(2, '0')}.${String(t % 60).padStart(2, '0')}` }
    })
  }, [wake])
  return (
    <div className="grid gap-10 md:grid-cols-[auto_1fr] md:items-center">
      <label className="block">
        <span className="text-sm font-medium text-ink/70">Aku ingin bangun pukul</span>
        <input
          type="time"
          value={wake}
          onChange={(e) => setWake(e.target.value || '06:00')}
          className="mt-2 block rounded-2xl bg-forest px-6 py-4 font-display text-5xl text-cream outline-none ring-clay focus:ring-4"
        />
      </label>
      <div>
        <p className="text-sm text-ink/60">Waktu terbaik untuk mulai tidur:</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          {times.map((t, i) => (
            <div key={t.cycles} className={`rounded-[1.5rem] p-6 transition hover:-translate-y-1 ${i === 0 ? 'bg-forest text-cream' : 'bg-cream'}`}>
              <p className="font-display text-4xl">{t.at}</p>
              <p className="mt-1 text-sm opacity-70">
                {t.cycles} siklus · {nf(t.hours, 1)} jam
              </p>
              {i === 0 && <p className="mt-3 inline-block rounded-full bg-butter px-2.5 py-0.5 text-xs font-semibold text-forest">Direkomendasikan</p>}
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-ink/50">Sudah termasuk rata-rata 15 menit untuk terlelap. Satu siklus tidur ±90 menit.</p>
      </div>
    </div>
  )
}
