export type Article = {
  slug: string
  title: string
  excerpt: string
  category: 'Nutrisi' | 'Tidur' | 'Gerak' | 'Mental' | 'Jantung'
  image: string
  readMinutes: number
  author: string
  date: string
  body: { heading?: string; text: string }[]
  tips: string[]
}

// Konten jurnal statis. Ganti dengan CMS/database bila jumlah artikel bertambah.
const articles: Article[] = [
  {
    slug: 'piring-seimbang-isi-piringku',
    title: 'Isi Piringku: Cara Sederhana Menyusun Piring Seimbang',
    excerpt: 'Separuh sayur dan buah, seperempat karbohidrat, seperempat protein — panduan praktis untuk makan sehari-hari.',
    category: 'Nutrisi',
    image: 'nutrisi.png',
    readMinutes: 5,
    author: 'dr. Ayu Lestari, Sp.GK',
    date: '2 Oktober 2026',
    body: [
      { text: 'Makan sehat tidak harus rumit. Konsep "Isi Piringku" dari Kementerian Kesehatan membagi satu piring makan menjadi porsi-porsi yang mudah diingat, sehingga kebutuhan gizi harian terpenuhi tanpa perlu menghitung kalori setiap saat.' },
      { heading: 'Separuh piring: sayur dan buah', text: 'Sayuran berwarna-warni dan buah memberi serat, vitamin, dan antioksidan. Usahakan sayur porsinya lebih banyak daripada buah, dan variasikan warnanya setiap hari — hijau, oranye, merah, ungu.' },
      { heading: 'Seperempat: makanan pokok', text: 'Pilih karbohidrat kompleks seperti nasi merah, kentang, jagung, ubi, atau roti gandum. Karbohidrat kompleks dicerna lebih lambat sehingga energi lebih stabil dan rasa kenyang bertahan lebih lama.' },
      { heading: 'Seperempat: lauk pauk', text: 'Gabungkan protein hewani (ikan, telur, ayam) dan nabati (tempe, tahu, kacang-kacangan). Tempe adalah superfood lokal yang kaya protein, serat, dan probiotik alami.' },
      { text: 'Lengkapi dengan minum air putih yang cukup, batasi gula, garam, dan lemak, serta cuci tangan sebelum makan.' },
    ],
    tips: ['Gunakan piring berdiameter 23 cm agar porsi terkendali', 'Masak dengan cara dikukus, direbus, atau ditumis sedikit minyak', 'Batasi gula 4 sdm, garam 1 sdt, minyak 5 sdm per hari'],
  },
  {
    slug: 'rahasia-tidur-berkualitas',
    title: 'Rahasia Tidur Berkualitas: Ritual 60 Menit Sebelum Lelap',
    excerpt: 'Kualitas tidur ditentukan oleh apa yang kamu lakukan satu jam sebelum memejamkan mata.',
    category: 'Tidur',
    image: 'tidur.png',
    readMinutes: 6,
    author: 'dr. Bima Prasetyo, Sp.N',
    date: '28 September 2026',
    body: [
      { text: 'Orang dewasa membutuhkan 7–9 jam tidur setiap malam. Namun durasi saja tidak cukup — kualitas tidur sangat dipengaruhi oleh ritme sirkadian dan kebiasaan menjelang tidur.' },
      { heading: 'Redupkan cahaya', text: 'Cahaya biru dari layar menekan produksi melatonin. Matikan gawai minimal 30–60 menit sebelum tidur, atau gunakan mode malam dengan kecerahan rendah.' },
      { heading: 'Atur suhu kamar', text: 'Suhu kamar ideal untuk tidur berkisar 18–24°C. Tubuh perlu sedikit menurunkan suhu inti agar dapat memasuki fase tidur dalam.' },
      { heading: 'Konsisten adalah kunci', text: 'Bangun dan tidur di jam yang sama setiap hari — termasuk akhir pekan — membantu jam biologis tubuh bekerja lebih teratur.' },
    ],
    tips: ['Hindari kafein setelah pukul 14.00', 'Coba latihan napas 4-7-8 di tempat tidur', 'Tulis 3 hal yang kamu syukuri hari ini'],
  },
  {
    slug: 'gerak-150-menit',
    title: '150 Menit Seminggu: Target Aktivitas Fisik yang Realistis',
    excerpt: 'Tidak perlu gym mahal. Jalan cepat 30 menit, lima hari seminggu, sudah memberi dampak besar.',
    category: 'Gerak',
    image: 'olahraga.png',
    readMinutes: 4,
    author: 'Rizky Hidayat, S.Ft',
    date: '21 September 2026',
    body: [
      { text: 'WHO merekomendasikan orang dewasa melakukan 150–300 menit aktivitas fisik intensitas sedang per minggu, ditambah latihan kekuatan otot minimal dua kali seminggu.' },
      { heading: 'Mulai dari yang kecil', text: 'Naik tangga, bersepeda ke warung, atau jalan kaki saat menelepon — semua menit itu terhitung. Mulailah dengan 10 menit, lalu tingkatkan bertahap.' },
      { heading: 'Latihan kekuatan di rumah', text: 'Squat, push-up dinding, plank, dan lunges bisa dilakukan tanpa alat. Lakukan 2–3 set, 10–15 repetisi, dua kali seminggu.' },
    ],
    tips: ['Gunakan zona detak jantung 50–70% untuk intensitas sedang', 'Lakukan peregangan 5 menit sebelum dan sesudah', 'Ajak teman agar lebih konsisten'],
  },
  {
    slug: 'merawat-kesehatan-mental',
    title: 'Merawat Pikiran: 5 Kebiasaan Kecil untuk Kesehatan Mental',
    excerpt: 'Kesehatan mental sama pentingnya dengan kesehatan fisik. Ini kebiasaan kecil yang bisa dimulai hari ini.',
    category: 'Mental',
    image: 'mental.png',
    readMinutes: 5,
    author: 'Nadia Putri, M.Psi., Psikolog',
    date: '14 September 2026',
    body: [
      { text: 'Stres adalah bagian alami kehidupan, tetapi stres berkepanjangan dapat memengaruhi tidur, nafsu makan, hingga sistem imun. Merawat pikiran adalah investasi jangka panjang.' },
      { heading: 'Bernapas dengan sadar', text: 'Latihan napas perlahan mengaktifkan sistem saraf parasimpatis yang menenangkan tubuh. Cukup 3 menit untuk merasakan perbedaannya.' },
      { heading: 'Terhubung dengan orang lain', text: 'Percakapan bermakna dengan teman atau keluarga terbukti menurunkan hormon stres. Jangan ragu untuk bercerita.' },
      { heading: 'Cari bantuan profesional', text: 'Jika perasaan cemas atau sedih berlangsung lebih dari dua minggu dan mengganggu aktivitas, konsultasikan dengan psikolog atau psikiater.' },
    ],
    tips: ['Jurnal syukur setiap malam', 'Batasi waktu media sosial', 'Habiskan 20 menit di alam terbuka'],
  },
  {
    slug: 'makanan-sahabat-jantung',
    title: 'Makanan Sahabat Jantung yang Mudah Ditemukan di Pasar',
    excerpt: 'Ikan kembung, kacang-kacangan, hingga buah bit — pilihan lokal untuk jantung yang lebih kuat.',
    category: 'Jantung',
    image: 'jantung.png',
    readMinutes: 4,
    author: 'dr. Hendra Wijaya, Sp.JP',
    date: '7 September 2026',
    body: [
      { text: 'Penyakit jantung adalah salah satu penyebab kematian tertinggi di Indonesia. Kabar baiknya, sebagian besar faktor risikonya bisa dikendalikan lewat pola makan.' },
      { heading: 'Omega-3 dari ikan lokal', text: 'Ikan kembung, sarden, dan tongkol kaya asam lemak omega-3 yang membantu menurunkan trigliserida — dan harganya jauh lebih terjangkau daripada salmon.' },
      { heading: 'Serat larut', text: 'Oatmeal, kacang merah, dan apel mengandung serat larut yang membantu menurunkan kolesterol LDL.' },
    ],
    tips: ['Konsumsi ikan minimal 2 kali seminggu', 'Ganti camilan gorengan dengan kacang panggang', 'Periksa tekanan darah secara rutin'],
  },
  {
    slug: 'hidrasi-cukup-setiap-hari',
    title: 'Sudah Cukup Minum Hari Ini? Panduan Hidrasi Harian',
    excerpt: 'Tubuh kita 60% air. Kekurangan 2% saja sudah bisa menurunkan konsentrasi dan energi.',
    category: 'Nutrisi',
    image: 'hero.png',
    readMinutes: 3,
    author: 'dr. Ayu Lestari, Sp.GK',
    date: '1 September 2026',
    body: [
      { text: 'Kebutuhan cairan rata-rata orang dewasa sekitar 30–35 ml per kilogram berat badan per hari, dan meningkat saat cuaca panas atau berolahraga.' },
      { heading: 'Kenali tanda dehidrasi', text: 'Urine berwarna gelap, sakit kepala, mudah lelah, dan bibir kering adalah sinyal tubuh membutuhkan cairan.' },
      { heading: 'Buat minum jadi kebiasaan', text: 'Simpan botol minum di meja, tambahkan irisan lemon atau daun mint, dan gunakan pelacak minum untuk memantau progres harian.' },
    ],
    tips: ['Minum segelas air setelah bangun tidur', 'Gunakan pelacak air di Alat Sehat', 'Perbanyak buah berair seperti semangka dan timun'],
  },
]

export default articles
