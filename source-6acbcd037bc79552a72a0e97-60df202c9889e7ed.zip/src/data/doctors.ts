export type Doctor = {
  id: string
  name: string
  specialty: string
  category: 'Umum' | 'Gizi' | 'Jantung' | 'Saraf' | 'Psikologi' | 'Anak'
  rating: number
  reviews: number
  experience: number
  schedule: string
  online: boolean
  tone: string
}

const doctors: Doctor[] = [
  { id: 'ayu', name: 'dr. Ayu Lestari, Sp.GK', specialty: 'Spesialis Gizi Klinik', category: 'Gizi', rating: 4.9, reviews: 412, experience: 11, schedule: 'Sen–Jum · 09.00–15.00', online: true, tone: 'bg-butter' },
  { id: 'hendra', name: 'dr. Hendra Wijaya, Sp.JP', specialty: 'Spesialis Jantung & Pembuluh Darah', category: 'Jantung', rating: 4.8, reviews: 356, experience: 15, schedule: 'Sel, Kam · 13.00–18.00', online: false, tone: 'bg-clay' },
  { id: 'bima', name: 'dr. Bima Prasetyo, Sp.N', specialty: 'Spesialis Saraf', category: 'Saraf', rating: 4.7, reviews: 228, experience: 9, schedule: 'Rab–Sab · 10.00–16.00', online: true, tone: 'bg-sage' },
  { id: 'nadia', name: 'Nadia Putri, M.Psi., Psikolog', specialty: 'Psikolog Klinis', category: 'Psikologi', rating: 5.0, reviews: 519, experience: 8, schedule: 'Setiap hari · 08.00–20.00', online: true, tone: 'bg-moss' },
  { id: 'sari', name: 'dr. Sari Rahmawati', specialty: 'Dokter Umum', category: 'Umum', rating: 4.8, reviews: 802, experience: 6, schedule: 'Setiap hari · 07.00–22.00', online: true, tone: 'bg-butter' },
  { id: 'dimas', name: 'dr. Dimas Arya, Sp.A', specialty: 'Spesialis Anak', category: 'Anak', rating: 4.9, reviews: 377, experience: 12, schedule: 'Sen–Sab · 08.00–14.00', online: false, tone: 'bg-sage' },
]

export default doctors
