# Sehatara

Sehatara adalah website kesehatan berbahasa Indonesia dengan tema "botanical editorial" — krem hangat, hijau hutan, dan terakota — serta animasi halus di seluruh halaman. Website ini menggabungkan alat ukur kesehatan interaktif, jurnal artikel dari tenaga ahli, dan formulir janji konsultasi dokter.

## Fitur

- **Beranda** — hero animasi (badge berputar, grafik detak jantung, gelombang air), marquee, bento fitur unggulan, cek kebiasaan harian dengan skor cincin, statistik count-up, cuplikan jurnal, testimoni, dan CTA.
- **Alat Sehat** (`/alat`) — Kalkulator BMI, kebutuhan kalori (Mifflin-St Jeor + makro), pelacak minum air (tersimpan per hari di perangkat), latihan napas 4-7-8 terpandu, zona detak jantung (Karvonen), dan kalkulator jam tidur berbasis siklus 90 menit.
- **Jurnal** (`/artikel`) — daftar artikel dengan filter kategori dan pencarian; halaman detail dengan progress bar baca, drop cap, dan tips praktis.
- **Konsultasi** (`/konsultasi`) — direktori dokter dengan filter spesialisasi dan formulir janji temu yang dikirim lewat Netlify Forms.

## Teknologi

TanStack Start (React 19), Tailwind CSS 4, Lucide icons, Netlify Forms, Netlify Image CDN. Gambar dibuat dengan AI dan disimpan di `public/img`.

## Menjalankan secara lokal

```bash
pnpm install
netlify dev   # atau: pnpm dev
```

Netlify Forms hanya memproses kiriman pada deploy Netlify (bukan dev lokal).
