# AGENTS.md

## Project
Sehatara — Indonesian-language health website (UI copy in Bahasa Indonesia). TanStack Start + React 19 + Tailwind CSS 4, deployed on Netlify.

## Structure
- `src/routes/__root.tsx` — HTML shell, global meta, Header + Footer.
- `src/routes/index.tsx` — landing page (all sections are local components in this file).
- `src/routes/alat.tsx` — health tools page; tool implementations live in `src/components/tools.tsx`.
- `src/routes/artikel/index.tsx`, `src/routes/artikel/$slug.tsx` — journal list + detail.
- `src/routes/konsultasi.tsx` — doctor directory + booking form (Netlify Forms).
- `src/data/articles.ts`, `src/data/doctors.ts` — static content. Swap for a CMS / Netlify Database if content becomes dynamic.
- `src/components/Reveal.tsx` — IntersectionObserver scroll-reveal wrapper (uses `.reveal` CSS in `styles.css`).
- `src/lib/img.ts` — builds Netlify Image CDN URLs for files in `public/img`. Always use it instead of raw `/img/...` paths.

## Design system
Theme tokens are defined in `@theme` in `src/styles.css`: colors `cream, paper, forest, moss, sage, clay, butter, ink`; fonts `font-display` (Fraunces) and `font-sans` (Plus Jakarta Sans); animations `animate-float`, `animate-blob`, `animate-marquee`, `animate-spin-slow`, `animate-pulse-ring`. Use `.rise` for on-load entrance and `<Reveal>` for on-scroll. Headings use light-weight Fraunces with an italic `<em>` accent in `text-clay`.

## Non-obvious decisions
- Netlify Forms: the form `konsultasi` is registered via the static skeleton `public/__forms.html`; the React form POSTs URL-encoded data to `/__forms.html` (not `/`, which SSR would intercept). Keep field names in sync between the skeleton and `BookingForm`.
- The water tracker stores the daily count in `localStorage` (key `sehatara-air-YYYY-MM-DD`) — personal, per-device, no account needed.
- Health tool results are educational estimates; keep the disclaimers.
